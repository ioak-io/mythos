export type Assessment = {
  name: string;
  jobDescription?: string;
  duration?: string;
};
