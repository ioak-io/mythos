export type AssessmentResponse = {
  assessmentId: string;
  participantEmail: string;
  status: boolean;
  score: string;
};
