export type AssessmentResponseAnswer = {
  assessmentResponseId: string;
  assessmentQuestionId: string;
  answer: string;
  score: string;
};
