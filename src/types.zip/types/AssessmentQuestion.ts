export type AssessmentQuestion = {
  assessmentId: string;
  type: string;
  question: string;
  answer: string;
  choices: string[];
};
